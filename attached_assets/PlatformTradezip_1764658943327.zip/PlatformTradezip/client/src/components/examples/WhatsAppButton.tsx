import WhatsAppButton from '../WhatsAppButton';

export default function WhatsAppButtonExample() {
  return <WhatsAppButton />;
}
