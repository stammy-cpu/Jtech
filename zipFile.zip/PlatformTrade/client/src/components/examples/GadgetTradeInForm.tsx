import GadgetTradeInForm from '../GadgetTradeInForm';

export default function GadgetTradeInFormExample() {
  return (
    <div className="p-8">
      <GadgetTradeInForm />
    </div>
  );
}
