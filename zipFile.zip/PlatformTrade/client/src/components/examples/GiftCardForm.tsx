import GiftCardForm from '../GiftCardForm';

export default function GiftCardFormExample() {
  return (
    <div className="p-8">
      <GiftCardForm />
    </div>
  );
}
