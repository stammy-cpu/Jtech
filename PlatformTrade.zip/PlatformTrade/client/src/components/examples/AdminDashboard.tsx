import AdminDashboard from '../AdminDashboard';

export default function AdminDashboardExample() {
  return (
    <div className="p-8">
      <AdminDashboard />
    </div>
  );
}
