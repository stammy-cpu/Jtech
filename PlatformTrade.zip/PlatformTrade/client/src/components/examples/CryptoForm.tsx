import CryptoForm from '../CryptoForm';

export default function CryptoFormExample() {
  return (
    <div className="p-8">
      <CryptoForm />
    </div>
  );
}
